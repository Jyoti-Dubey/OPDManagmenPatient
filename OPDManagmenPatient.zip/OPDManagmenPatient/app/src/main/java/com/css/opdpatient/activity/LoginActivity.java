package com.css.opdpatient.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.css.opdpatient.R;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }
}
