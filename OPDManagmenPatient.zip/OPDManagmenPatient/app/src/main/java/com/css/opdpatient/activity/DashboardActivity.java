package com.css.opdpatient.activity;

import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.view.View;

import com.css.opdpatient.R;

/***
 * Created By : Jyoti on 20 Jan 2018 (Saturday)
 * Functionality : This class will show the dashboard of Patient Application
 */

public class DashboardActivity extends ParentActivity {

    private String TAG = "DashboardActivity";
    private DrawerLayout drawerLayout;
    private View fragment;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        initUIControls();

        initTopBarComponents();

        registerForListener();

        setUIData();
    }

    @Override
    void initUIControls() {
        drawerLayout = findViewById(R.id.drawerLayout);
        fragment = findViewById(R.id.fragment);
    }

    @Override
    void registerForListener() {
        imgTopLeft.setOnClickListener(this);
    }

    @Override
    void setUIData() {
        txtTopCenter.setText(getResources().getString(R.string.top_dashboard));
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.imgTopLeft:
                openDrawer(drawerLayout, fragment);
                break;
        }
    }
}   //end of DashboardActivity
