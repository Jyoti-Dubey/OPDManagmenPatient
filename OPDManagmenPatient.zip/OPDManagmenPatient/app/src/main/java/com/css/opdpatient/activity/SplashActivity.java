package com.css.opdpatient.activity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.RelativeLayout;

import com.css.opdpatient.R;
import com.css.opdpatient.utils.PreferenceManager;

import static com.css.opdpatient.utils.StringUtils.PREF_USER_NAME;


/***
 * Created By : PG on 20 Jan 2018 (Saturday)
 * Functionality :  First screen of the application
 *This is Patient application
 */

public class SplashActivity extends ParentActivity {

    private String TAG = "SplashActivity";
    private RelativeLayout mainRelative;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setFullScreen();

        setContentView(R.layout.activity_splash);

        initUIControls();

        registerForListener();

        startHandler();

        PreferenceManager.setStringPreference(this, PREF_USER_NAME, "Jyoti");
        Log.d(TAG, "User name :: " + PreferenceManager.getStringPreference(this, PREF_USER_NAME));
    }

    private void startHandler() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(3000);
                    navigateToActivity(DashboardActivity.class, true);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    @Override
    void initUIControls() {
        mainRelative = findViewById(R.id.mainRelative);
    }

    @Override
    void registerForListener() {
        mainRelative.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.mainRelative:
                navigateToActivity(DashboardActivity.class, true);
                break;
        }
    }
}   //end of class SplashActivity
