package com.css.opdpatient.utils;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by PG on 19 Jan 2018 Friday
 * All preference data will be stored here
 */

public class PreferenceManager {

    private static final String PREF_NAME = "opd_preference";
    private static final int PRIVATE_MODE = 0;

    /***
     * set string preference
     * @param context
     * @param keyName
     * @param keyValue
     */
    public static void setStringPreference(Context context, String keyName, String keyValue) {
        SharedPreferences pref = context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(keyName, keyValue);
        editor.apply();
    }//end of setStringPreference() for string

    /**
     * get preference by key
     *
     * @param context
     * @param keyName
     * @return
     */
    public static String getStringPreference(Context context, String keyName) {
        SharedPreferences pref = context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        return pref.getString(keyName, "");
    }//end of getStringPreference() for string values

}   //end of PreferenceManager
