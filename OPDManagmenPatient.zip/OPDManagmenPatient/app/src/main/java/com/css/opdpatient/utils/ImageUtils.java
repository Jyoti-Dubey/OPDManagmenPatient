package com.css.opdpatient.utils;

import android.content.Context;
import android.util.Log;
import android.widget.ImageView;

import com.css.opdpatient.R;
import com.squareup.picasso.Picasso;

/***
 * Project created by PG on 19 Jan 2018 Friday
 * ImageUtils will load user image from url
 */
public class ImageUtils {

    static String TAG = "ImageUtils";

    /***
     * will set user image
     * @param context
     * @param imageUrl
     * @param targetImageView
     */
    public static void setImage(Context context, final String imageUrl, ImageView targetImageView) {
        if (imageUrl != null) {
            Picasso.with(context)
                    .load(imageUrl)
                    .placeholder(R.drawable.default_user)
                    .into(targetImageView, new com.squareup.picasso.Callback() {
                        @Override
                        public void onSuccess() {
                            Log.d(TAG, "loadImagePicasso :: onSuccess :: " + imageUrl);
                        }

                        @Override
                        public void onError() {
                            Log.d(TAG, "loadImagePicasso :: onError :: " + imageUrl);
                        }
                    });
        } else {
            targetImageView.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.default_user));
        }
    }   //end of setImage
}   //end of ImageUtils
